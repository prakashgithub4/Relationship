﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","et",{title:"Värvivalija kasutajaliides",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Eelmääratud värvikomplektid",config:"Aseta see sõne oma config.js faili."});